/* Auto-generated config file stdio_redirect_config.h */
#ifndef STDIO_REDIRECT_CONFIG_H
#define STDIO_REDIRECT_CONFIG_H

// <<< Use Configuration Wizard in Context Menu >>>

// <<< end of configuration section >>>

#endif // STDIO_REDIRECT_CONFIG_H
